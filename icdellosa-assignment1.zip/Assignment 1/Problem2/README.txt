PROBLEM STATEMENT:
In this assignment, you are tasked to implemented a Bag ADT using links.

WHAT IS PROVIDED:
- A driver class to test your code. You should not modify this file!
- A bag interface (BagInterface.java)

WHAT YOU NEED TO DO:
1. Create a LinkedBag class (LinkedBag.java) that implemented the bag interface
2. Create an inner class Node inside LinkedBag
3. Run the driver and make sure your output is exactly the same as mine (at the bottom of Driver.java)